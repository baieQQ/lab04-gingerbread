"""Browser entry point (pygbag compiles this to WebAssembly).

Everything is wrapped so a failure is *visible*.  Under WebAssembly an
uncaught exception goes nowhere the developer can see: the loading banner
simply stays up forever, and the browser console shows only the runtime's own
chatter.  Writing the traceback into the document turns a silent hang into a
message that can be read and fixed.
"""

import asyncio
import os
import sys
import traceback

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")


def _show(text):
    try:
        import platform
        platform.window.document.title = text[:120]
        el = platform.window.document.createElement("pre")
        el.id = "boot-error"
        el.style.cssText = ("position:fixed;left:0;top:0;z-index:99999;"
                            "background:#111;color:#f66;font:12px monospace;"
                            "padding:12px;white-space:pre-wrap;max-width:100%")
        el.textContent = text
        platform.window.document.body.appendChild(el)
    except Exception:
        print(text, file=sys.stderr)


def _mark(step):
    """Leave a breadcrumb in the tab title, so a hang says where it hung."""
    try:
        import platform
        platform.window.document.title = "boot: " + step
    except Exception:
        pass


async def main() -> None:
    # Everything is inside the coroutine because pygbag's ``asyncio.run``
    # schedules and returns immediately — a try/except around *it* catches
    # nothing, which is why the first attempt at this reported no error at all.
    try:
        _mark("import")
        # **Not fullscreen.**  ``set_mode((0, 0), FULLSCREEN)`` means "the whole
        # desktop" on a desktop; under WebAssembly there is no desktop.
        from gingerbread.app.game import Game

        _mark("construct")
        game = Game(seed=42, fullscreen=False)
        _mark("run")
        await game.run()
    except BaseException:
        _show(traceback.format_exc())
        raise


asyncio.run(main())
